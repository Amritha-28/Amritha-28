package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Customers;
import com.exception.ResourceNotFoundException;
import com.repository.CustomersRepository;

@Service
public class CustomersServiceImpl implements CustomersService {

	@Autowired
	private CustomersRepository customersRepository;
	
	@Override
	public List<Customers> getAllCustomers() {
		
		return customersRepository.findAll();
	}

	@Override
	public Customers registerCustomer(Customers customers) {
		
		return customersRepository.save(customers);
	}

	@Override
	public Customers updateCustomer(Integer customerid, Customers customer) {
		Customers customer1 = customersRepository.findById(customerid).get();
		Customers customerdb= null;
		if(customer1 != null)
		{
			customerdb = customersRepository.findById(customerid).get();
			
			customerdb.setFirstName(customer.getFirstName());
			customerdb.setLastName(customer.getLastName());
			customerdb.setAddress(customer.getAddress());
			customerdb.setPhoneNumber(customer.getPhoneNumber());
			customerdb.setEmailId(customer.getEmailId());
			System.out.println(customerdb);
			return customersRepository.save(customerdb);
		}
		else
		{
			throw new ResourceNotFoundException("Customer", "customerid", customerid);
		}
	}

	@Override
	public void deleteCustomerById(Integer customerid) {
		Customers customer = customersRepository.findById(customerid).get();
		if(customer != null)
		{
			customersRepository.deleteById(customerid);
		}
		else
		{
			throw new ResourceNotFoundException("Customer", "customerid" , customerid);
		}
		
	}

	

}
