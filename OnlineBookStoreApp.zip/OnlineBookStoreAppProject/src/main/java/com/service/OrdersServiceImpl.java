package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Books;
import com.entity.Orders;
import com.exception.ResourceNotFoundException;
import com.repository.BooksRepository;
import com.repository.OrdersRepository;

@Service
public class OrdersServiceImpl implements OrdersService {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	private BooksRepository booksRepository;

	@Override
	public List<Orders> getAllOrders() {
		
		return ordersRepository.findAll();
	}

	@Override
	public Orders placeNewOrder(Orders orders) {
		
		return ordersRepository.save(orders);
	}

	@Override
	public Orders updateOrderDetails(Integer orderid, Orders order) {
		Orders orders = ordersRepository.findById(orderid).get();
		Orders orderdb = null;
		if(orders != null)
		{
			orderdb = ordersRepository.findById(orderid).get();
			
			orderdb.setQuantity(order.getQuantity());
			orderdb.setOrderDate(order.getOrderDate());
			orderdb.setTotalPrice(order.getTotalPrice());
			System.out.println(orderdb);
			return ordersRepository.save(orderdb);
		}
		else
		{
			throw new ResourceNotFoundException("Orders", "Orderid", orderid);
		}
	}

	@Override
	public void deleteOrderById(Integer orderid) {
		Orders orders = ordersRepository.findById(orderid).get();
		if(orders != null)
		{
			ordersRepository.deleteById(orderid);
		}
		else
		{
			throw new ResourceNotFoundException("Orders", "Orderid", orderid);
		}
		
	}

	@Override
	public Orders addBookToOrderList(Integer orderid, Integer bookid) {
		Orders order = ordersRepository.findById(orderid).get();
		Books book = booksRepository.findById(bookid).get();
		if(order != null && book != null)
		{
			order.orderedBook(book);
			return ordersRepository.save(order);
		}
		else
		{
			throw new ResourceNotFoundException("Orders", "Orderid", orderid);
		}
	}
	
	
	
	
}
