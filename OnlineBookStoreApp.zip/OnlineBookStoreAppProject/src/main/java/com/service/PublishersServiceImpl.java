package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Publishers;
import com.exception.ResourceNotFoundException;
import com.repository.PublishersRepository;

@Service
public class PublishersServiceImpl implements PublishersService{

	@Autowired
	private PublishersRepository publishersRepository;
	
	@Override
	public List<Publishers> getAllPublishers() {
		
		return publishersRepository.findAll();
	}

	@Override
	public Publishers registerPublisher(Publishers publishers) {
		
		return publishersRepository.save(publishers);
	}

	@Override
	public void deletePublisherById(Integer publisherid) {
		Publishers publishers = publishersRepository.findById(publisherid).get();
		if(publishers != null)
		{
			publishersRepository.deleteById(publisherid);
		}
		else
		{
			throw new ResourceNotFoundException("Publisher", "publisherid", publisherid);
		}
		
	}

	@Override
	public Publishers updatePublisherById(Integer publisherid, Publishers publisher) {
		Publishers publishers = publishersRepository.findById(publisherid).get();
		Publishers publisherdb= null;
		if(publishers != null)
		{
			publisherdb = publishersRepository.findById(publisherid).get();
			publisherdb.setPublicationName(publisher.getPublicationName());
			System.out.println(publisherdb);
			return publishersRepository.save(publisherdb);
		}
		else
		{
			throw new ResourceNotFoundException("Publisher", "publisherid", publisherid);
		}
	}
	
	
	
	

}
