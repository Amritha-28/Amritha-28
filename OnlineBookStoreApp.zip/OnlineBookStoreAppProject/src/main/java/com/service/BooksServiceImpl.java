package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Authors;
import com.entity.Books;
import com.entity.Publishers;
import com.exception.ResourceNotFoundException;
import com.repository.AuthorsRepository;
import com.repository.BooksRepository;
import com.repository.PublishersRepository;

@Service
public class BooksServiceImpl implements BooksService {

	@Autowired
	private BooksRepository booksRepository;
	
	@Autowired
	private AuthorsRepository authorsRepository;
	
	@Autowired
	private PublishersRepository publishersRepository;
	
	@Override
	public List<Books> getAllBooks() {
		
		return booksRepository.findAll();
	}
	
	@Override
	public Books registerBook(Books books) {
		
		return booksRepository.save(books);
	}

	@Override
	public Books updateAuthorToBook(Integer bookid, Integer authorid) {
		Books books = booksRepository.findById(bookid).get();
		Authors authors = authorsRepository.findById(authorid).get();
		if(books != null && authors != null)
		{
		books.bookAuthor(authors);
		return booksRepository.save(books);
		}
		else
		{
			throw new ResourceNotFoundException("Books", "bookid", bookid);
		}
	}

	@Override
	public Books updatePublisherToBook(Integer bookid, Integer publisherid) {
		
		Books books = booksRepository.findById(bookid).get();
		Publishers publishers = publishersRepository.findById(publisherid).get();
		if(books != null && publishers != null)
		{
		books.bookPublisher(publishers);
		return booksRepository.save(books);
		}
		else
		{
			throw new ResourceNotFoundException("Books", "bookid", bookid);
		}
		
	}
	

	
	@Override
	public void deleteBookById(Integer bookid) {
		Books books = booksRepository.findById(bookid).get();
		if(books != null)
			booksRepository.deleteById(bookid);
		else
			throw new ResourceNotFoundException("Books", "bookid", bookid);
		
	}

	@Override
	public Books updateBook(Integer bookid, Books book) {
		Books book1 = booksRepository.findById(bookid).get();
		Books bookdb = null;
		if(book1 != null)
		{
			bookdb = booksRepository.findById(bookid).get();
			
			bookdb.setBookTitle(book.getBookTitle());
			bookdb.setBookISBN(book.getBookISBN());
			bookdb.setBookGenre(book.getBookGenre());
			bookdb.setPublicationYear(book.getPublicationYear());
			bookdb.setBookPrice(book.getBookPrice());
			System.out.println(bookdb);
			return booksRepository.save(bookdb);
			
		}
		else
		{
			throw new ResourceNotFoundException("Books", "bookid", bookid);
		}
	}

}
