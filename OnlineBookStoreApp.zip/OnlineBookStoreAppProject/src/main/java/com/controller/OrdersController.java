package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Customers;
import com.entity.Orders;
import com.repository.CustomersRepository;
import com.repository.OrdersRepository;
import com.request.OrdersRequest;
import com.service.OrdersService;

@RestController
public class OrdersController {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	private CustomersRepository customersRepository;
	
	@Autowired
	private OrdersService ordersService;
	
	@GetMapping("/getAllOrders")
	public List<Orders> getAllOrders()
	{
		return ordersService.getAllOrders();
	}
	

	@PutMapping("/updateOrderById/{orderid}")
	public ResponseEntity<Orders> updateOrderDetails(@PathVariable("orderid") Integer orderid, @RequestBody Orders order)
	{
		return new ResponseEntity<Orders>(ordersService.updateOrderDetails(orderid,order) , HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteOrderById/{orderid}")
	public ResponseEntity<String> deleteOrderById(@PathVariable("orderid") Integer orderid)
	{
		ordersService.deleteOrderById(orderid);
		return new ResponseEntity<String>("Your Order is cancelled successfully!" , HttpStatus.OK);
	}

	
	@PutMapping("/order/{orderid}/book/{bookid}")
	public ResponseEntity<Orders> addBookToOrderList(@PathVariable Integer orderid , @PathVariable Integer bookid)
	{
		return new ResponseEntity<Orders>(ordersService.addBookToOrderList(orderid,bookid) , HttpStatus.OK);
	}
	
	@PostMapping("/placeNewOrder")
	public ResponseEntity<Orders> addCustomerToOrder(@Valid @RequestBody OrdersRequest request)
	{
		Customers customer = new Customers();
		customer.setFirstName(request.getFirstName());
		customer.setLastName(request.getLastName());
		customer.setPhoneNumber(request.getPhoneNumber());
		customer.setEmailId(request.getEmailId());
		customer.setAddress(request.getAddress());
		customer= customersRepository.save(customer);
		
		Orders order = new Orders(request);
		order.setCustomer(customer);
		order= ordersRepository.save(order);
		return new ResponseEntity<Orders>(order , HttpStatus.OK);
	}
	
}
