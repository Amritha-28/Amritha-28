package com.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;


@Entity
@SequenceGenerator(name = "bookseq" , initialValue = 2001)
public class Books {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "bookseq")
	private Integer bookId;
	
	@NotBlank(message = "Book title should not be blank")
	private String bookTitle;
	
	@Column(unique = true)
	@NotBlank(message = "ISBN should not be blank")
	@Length(min = 13 , max = 18 , message = "ISBN should have 13 digits" )
	private String bookISBN;
	
	@NotBlank(message = "Type of the book should not be blank")
	private String bookGenre;
	
	private Integer publicationYear;
	private Float bookPrice;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "author_id" , referencedColumnName = "authorId")
	private Authors authors;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "publisher_id" , referencedColumnName = "publisherId")
	private Publishers publishers;
	
	
	//no argument constructor
	public Books() {
		super();
	}

	//getters and setters
	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookISBN() {
		return bookISBN;
	}

	public void setBookISBN(String bookISBN) {
		this.bookISBN = bookISBN;
	}

	public String getBookGenre() {
		return bookGenre;
	}

	public void setBookGenre(String bookGenre) {
		this.bookGenre = bookGenre;
	}

	
	public Integer getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(Integer publicationYear) {
		this.publicationYear = publicationYear;
	}

	public Float getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(Float bookPrice) {
		this.bookPrice = bookPrice;
	}

	public Authors getAuthors() {
		return authors;
	}

	public void setAuthors(Authors authors) {
		this.authors = authors;
	}

	public void bookAuthor(Authors authors) {
		this.authors = authors;
		
	}


	public void bookPublisher(Publishers publishers) {
		this.publishers = publishers;
		
	}

	
	public Publishers getPublishers() {
		return publishers;
	}

	public void setPublishers(Publishers publishers) {
		this.publishers = publishers;
	}
	
	
	
	
	

}
