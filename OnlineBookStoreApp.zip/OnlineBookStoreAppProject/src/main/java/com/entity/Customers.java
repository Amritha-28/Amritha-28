package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

@Entity
@SequenceGenerator(name = "custseq" , initialValue = 10001)
public class Customers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "custseq")
	private Integer customerId;
	
	@NotBlank(message = "First name should not be blank")
	@Length(max = 30)
	private String firstName;
	
	@NotBlank(message = "Last name should not be blank")
	@Length(max = 30)
	private String lastName;
	
	@NotBlank(message = "Communication address should not be blank")
	private String address;
	
	@NotBlank(message = "Phone number should not be blank")
	@Length(min = 10 , max = 10 , message = "Phone number should have 10 digits")
	private String phoneNumber;
	
	@Column(unique = true)
	@NotBlank(message = "Email id should not be blank")
	@Email(message = "Enter valid email id")
	private String emailId;
	
	//no argument constructor
	public Customers() {
		super();
	}

	
	//getters and setters
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	

}
