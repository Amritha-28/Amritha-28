package com.entity;

import java.time.LocalDate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.request.OrdersRequest;

@Entity
@SequenceGenerator(name = "orderseq" , initialValue = 50001)
public class Orders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "orderseq")
	private Integer orderId;
	
	
	private Integer quantity;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate orderDate;
	
	private float totalPrice;
	
	@ManyToMany
	@JoinTable(name = "book_id" , joinColumns = @JoinColumn(name = "order_id"), inverseJoinColumns = @JoinColumn(name = "book_id"))
	private Set<Books> purchasedBooks = new HashSet<>();
	
	@OneToOne
	@JoinColumn(name = "customerId")
	private Customers customer;
	
	//Default constructor
	public Orders() {
		super();
	}

	//getters and setters
	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Set<Books> getPurchasedBooks() {
		return purchasedBooks;
	}

	public void setPurchasedBooks(Set<Books> purchasedBooks) {
		this.purchasedBooks = purchasedBooks;
	}

	public void orderedBook(Books book) {
		purchasedBooks.add(book);
		
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}

	public Orders(Integer orderId, Integer quantity, LocalDate orderDate, float totalPrice) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", quantity=" + quantity + ", orderDate=" + orderDate + ", totalPrice="
				+ totalPrice + "]";
	}

	
	public Orders(OrdersRequest request) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
	}
	

	
	
	
	
	
	
	
}
